﻿param([string]$Scripts)
$ErrorActionPreference='Stop';$script:checks=0
function Check($b,$message){if(!$b){throw $message};$script:checks++;Write-Output ('PASS: '+$message)}
foreach($file in Get-ChildItem $Scripts -Filter '*.ps1'){$tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($file.FullName),[ref]$tokens,[ref]$errors);Check ($errors.Count -eq 0) ('Production PowerShell parses: '+$file.Name)}
. (Join-Path $Scripts 'common.ps1')
# All CIM, networking, registry, restart and DNS commands below are replaced with synthetic fixtures.
$script:changes=[Collections.Generic.List[string]]::new()
$script:nic=[pscustomobject]@{InterfaceGuid=[Guid]'12d42e38-60bf-40b2-8d81-99bc98939ce1';MacAddress='00-11-22-33-44-55';PermanentAddress='001122334455';Name='Synthetic Ethernet';ifIndex=12;HardwareInterface=$true;Virtual=$false;InterfaceType=6;AdminStatus='Up'}
$script:ipif=@{IPv4=[pscustomobject]@{Dhcp='Disabled';RouterDiscovery='Disabled';AutomaticMetric='Disabled';InterfaceMetric=12;NlMtu=1500};IPv6=[pscustomobject]@{Dhcp='Enabled';RouterDiscovery='Enabled';AutomaticMetric='Enabled';InterfaceMetric=25;NlMtu=1500}}
$script:dns=@{IPv4='192.0.2.53,192.0.2.54';IPv6=''}
$script:addresses=@();$script:routes=@()
foreach($store in @('ActiveStore','PersistentStore')){
 $script:addresses+=,[pscustomobject]@{InterfaceIndex=12;AddressFamily='IPv4';PrefixOrigin='Manual';IPAddress='192.0.2.10';PrefixLength=24;SkipAsSource=$false;Store=$store}
 $script:routes+=,[pscustomobject]@{InterfaceIndex=12;AddressFamily='IPv4';Protocol='NetMgmt';DestinationPrefix='0.0.0.0/0';NextHop='192.0.2.1';RouteMetric=10;Store=$store}
}
function Get-NetAdapter {param([switch]$Physical) @($script:nic,[pscustomobject]@{HardwareInterface=$false;Virtual=$true;InterfaceType=6;Name='Synthetic VPN'})}
function Get-CimInstance {param($ClassName,$Filter)
 if($ClassName -eq 'Win32_OperatingSystem'){return [pscustomobject]@{LastBootUpTime=[DateTime]'2026-01-01T00:00:00Z'}}
 if($ClassName -eq 'Win32_NetworkAdapter'){return [pscustomobject]@{GUID=[string]$script:nic.InterfaceGuid;PNPDeviceID='PCI\SYNTHETIC\INSTANCE'}}
 if($ClassName -eq 'Win32_PnPSignedDriver'){return [pscustomobject]@{DeviceID='PCI\SYNTHETIC\INSTANCE';InfName='oem12.inf';DriverVersion='1.2.3'}}
 throw ('Unmocked CIM class: '+$ClassName)
}
function Get-NetIPInterface {param($InterfaceIndex,$AddressFamily,$PolicyStore) if($InterfaceIndex -ne 12){throw 'Wrong interface'};$script:ipif[$AddressFamily]}
function Test-Path {param($LiteralPath) if($LiteralPath -notlike 'HKLM:*'){throw 'Unmocked path lookup'};$true}
function Get-ItemProperty {param($LiteralPath,$Path,$Name)
 if($Path -eq 'HKLM:\SOFTWARE\Microsoft\Cryptography' -or $LiteralPath -eq 'HKLM:\SOFTWARE\Microsoft\Cryptography'){return [pscustomobject]@{MachineGuid='synthetic-machine-guid'}}
 $af=if($LiteralPath -like '*Tcpip6*'){'IPv6'}else{'IPv4'};[pscustomobject]@{NameServer=$script:dns[$af]}
}
function Get-NetIPAddress {param($PolicyStore) @($script:addresses|Where-Object {$_.Store -eq $PolicyStore})}
function Get-NetRoute {param($PolicyStore) @($script:routes|Where-Object {$_.Store -eq $PolicyStore})}
function Set-NetIPInterface {param($InterfaceIndex,$AddressFamily,$Dhcp,$RouterDiscovery,$AutomaticMetric,$InterfaceMetric,$NlMtuBytes)
 if($InterfaceIndex -ne 12){throw 'Wrong interface mutation'};$script:changes.Add('interface:'+ $AddressFamily)
 $f=$script:ipif[$AddressFamily]
 foreach($name in @('Dhcp','RouterDiscovery','AutomaticMetric')){if($PSBoundParameters.ContainsKey($name)){$f.$name=$PSBoundParameters[$name]}}
 if($PSBoundParameters.ContainsKey('InterfaceMetric')){$f.InterfaceMetric=$InterfaceMetric};if($PSBoundParameters.ContainsKey('NlMtuBytes')){$f.NlMtu=$NlMtuBytes}
}
function New-NetIPAddress {param($InterfaceIndex,$IPAddress,$PrefixLength,$SkipAsSource,$PolicyStore)
 if($InterfaceIndex -ne 12){throw 'Wrong address mutation'}
 if($PolicyStore -and $PolicyStore -ne 'ActiveStore'){throw 'Windows forbids explicit PersistentStore for address creation'}
 $script:changes.Add('address:'+ $IPAddress)
 $stores=if($PolicyStore){@('ActiveStore')}else{@('ActiveStore','PersistentStore')}
 foreach($store in $stores){$script:addresses+=,[pscustomobject]@{InterfaceIndex=12;AddressFamily=$(if($IPAddress.Contains(':')){'IPv6'}else{'IPv4'});PrefixOrigin='Manual';IPAddress=$IPAddress;PrefixLength=$PrefixLength;SkipAsSource=$SkipAsSource;Store=$store}}
}
function New-NetRoute {param($InterfaceIndex,$DestinationPrefix,$NextHop,$RouteMetric,$PolicyStore)
 if($InterfaceIndex -ne 12){throw 'Wrong route mutation'}
 if($PolicyStore -and $PolicyStore -ne 'ActiveStore'){throw 'Windows forbids explicit PersistentStore for route creation'}
 $script:changes.Add('route:'+ $DestinationPrefix)
 $stores=if($PolicyStore){@('ActiveStore')}else{@('ActiveStore','PersistentStore')}
 foreach($store in $stores){$script:routes+=,[pscustomobject]@{InterfaceIndex=12;AddressFamily=$(if($NextHop.Contains(':')){'IPv6'}else{'IPv4'});Protocol='NetMgmt';DestinationPrefix=$DestinationPrefix;NextHop=$NextHop;RouteMetric=$RouteMetric;Store=$store}}
}
function InvokeDnsCommand {param([string[]]$parameters)
 if($parameters.Count -lt 6 -or $parameters[0] -ne 'interface' -or $parameters[4] -ne 'name=12'){throw 'DNS arguments not correctly scoped/splatted'}
 $af=if($parameters[1] -eq 'ipv4'){'IPv4'}else{'IPv6'};$script:changes.Add('dns:'+ $af)
 if($parameters[5] -eq 'source=dhcp'){$script:dns[$af]=''}
 elseif($parameters[2] -eq 'set'){$script:dns[$af]=$parameters[6].Substring(8)}
 elseif($parameters[2] -eq 'add'){$script:dns[$af]+=','+$parameters[5].Substring(8)}else{throw 'Unexpected DNS command'}
}
function Restart-NetAdapter {param($InputObject,[switch]$Confirm) if($InputObject.ifIndex -ne 12){throw 'Wrong restart target'};$script:changes.Add('restart')}
$list=& (Join-Path $Scripts 'discover.ps1')|ConvertFrom-Json
Check (@($list).Count -eq 1) 'Discovery excludes synthetic VPN and virtual adapters'
$inputData=$list[0]
Check ($inputData.Families[0].Addresses.Count -eq 2 -and $inputData.Families[0].Routes.Count -eq 2) 'Both persistent and active manual settings captured'
Check ($inputData.Families[0].ManualDns.Count -eq 2 -and !$inputData.Families[0].Dhcp) 'Static DNS order and static IPv4 captured'
Check ($inputData.Mac -eq '001122334455') 'Permanent hardware address used for identity'
& (Join-Path $Scripts 'restart.ps1')|Out-Null
Check ($script:changes.Count -eq 1 -and $script:changes[0] -eq 'restart') 'Restart targets one physical NIC only'
$script:addresses=@();$script:routes=@();$script:dns.IPv4='';$script:ipif.IPv4.Dhcp='Enabled'
& (Join-Path $Scripts 'restore.ps1')|Out-Null
Check (@($script:addresses).Count -eq 2 -and @($script:routes).Count -eq 2) 'Restore creates persistent and active entries without duplicate creations'
Check ($script:dns.IPv4 -eq '192.0.2.53,192.0.2.54' -and $script:dns.IPv6 -eq '') 'IPv4 DNS restored in order; IPv6 DNS automatic source retained'
Check ($script:ipif.IPv4.Dhcp -eq 'Disabled' -and $script:ipif.IPv6.Dhcp -eq 'Enabled') 'Static IPv4 not converted to DHCP; IPv6 DHCP kept'
$restored=& (Join-Path $Scripts 'read.ps1')|ConvertFrom-Json
Check ($restored.Families[0].Addresses.Count -eq 2 -and $restored.Families[0].ManualDns.Count -eq 2) 'Production readback confirms restored settings'
$before=$script:changes.Count
& (Join-Path $Scripts 'restore.ps1')|Out-Null
Check (@($script:addresses).Count -eq 2 -and @($script:routes).Count -eq 2) 'Repeated recovery is idempotent for addresses/routes'
$script:addresses[0] | Add-Member -NotePropertyName AddressState -NotePropertyValue Duplicate
try{& (Join-Path $Scripts 'read.ps1')|Out-Null;throw 'Duplicate IP accepted'}catch{Check ($_.Exception.Message.Contains('çakışması')) 'Duplicate IP readback fails clearly instead of claiming valid settings'}
$script:addresses[0].AddressState='Preferred'
$bad=$inputData|ConvertTo-Json -Depth 12|ConvertFrom-Json;$bad.PnpId='PCI\DIFFERENT'
$inputData=$bad
try{& (Join-Path $Scripts 'restore.ps1')|Out-Null;throw 'Wrong identity accepted'}catch{Check ($_.Exception.Message.Contains('kimliğine')) 'Different device refuses restore before mutation'}
Check ($script:changes.Count -ge $before) 'Only in-memory synthetic changes were exercised'
Write-Output ('ALL '+$script:checks+' WINDOWS SCRIPT FIXTURE CHECKS PASSED; NO REAL NIC MUTATION')
